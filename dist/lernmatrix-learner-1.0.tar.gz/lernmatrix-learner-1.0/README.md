# lernmatrix-learner
Lernmatrix structure for conditional learning and recall, based on human hippocampus' funcionality of associative memory learning and recall.
